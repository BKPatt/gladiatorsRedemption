﻿using System.Collections.Generic;
using UnityEngine.Events;

[System.Serializable]
public class DialogueNode
{
    public string npcName;
    public string dialogueText;
    public List<PlayerOption> playerOptions = new();
    public UnityEvent onNodeReached;
}

[System.Serializable]
public class PlayerOption
{
    public string optionText;
    public DialogueNode nextNode;
}
