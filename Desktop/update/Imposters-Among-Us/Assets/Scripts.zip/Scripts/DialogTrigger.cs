using UnityEngine;

public class DialogTrigger : MonoBehaviour
{
    public DialogueNode initialNode;
    private DialogManager dialogManager;

    // Start is called before the first frame update
    void Start()
    {
        dialogManager = GameObject.Find("DialogCanvas").GetComponent<DialogManager>();
    }

    private void OnMouseDown()
    {
        dialogManager.ShowDialog(initialNode);
    }
}
