using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class DialogManager : MonoBehaviour
{
    public GameObject dialogPanel;
    public Text npcNameText;
    public Text dialogText;
    public GameObject optionsPanel;
    public Button optionButtonPrefab;

    // Start is called before the first frame update
    void Start()
    {
        dialogPanel.SetActive(false);
    }

    public void ShowDialog(DialogueNode node)
    {
        dialogPanel.SetActive(true);
        npcNameText.text = node.npcName;
        dialogText.text = node.dialogueText;

        // Clear old buttons
        foreach (Transform child in optionsPanel.transform)
        {
            Destroy(child.gameObject);
        }

        // Create buttons for each option
        foreach (var option in node.playerOptions)
        {
            Button button = Instantiate(optionButtonPrefab, optionsPanel.transform);
            button.GetComponentInChildren<Text>().text = option.optionText;
            button.onClick.AddListener(() => ShowDialog(option.nextNode));
        }

        // Execute any UnityEvents (like scene changes, camera pans, etc.)
        node.onNodeReached?.Invoke();
    }

    public void HideDialog()
    {
        dialogPanel.SetActive(false);
    }
}
